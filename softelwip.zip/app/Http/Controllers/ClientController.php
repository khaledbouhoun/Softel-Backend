<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\Client;
use App\Models\ClientsNew;
use Illuminate\Support\Facades\Validator;


class ClientController extends Controller
{
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'CliGoogleId' => 'required|string|max:500',
        ]);
        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }
        // Check if the client exists in cleintnew table and client table
        $clientNew = ClientsNew::where('CliGoogleId', $request->CliGoogleId)->first();
        $client = Client::where('CliGoogleId', $request->CliGoogleId)->first();
        if (!$client && !$clientNew) {
            return response()->json(['message' => 'Client not found'], 404);
        } else {
            if ($client) {
                $client->tokens()->delete(); // Delete all previous tokens for the client
                $plainToken = $client->createToken('ClientToken')->plainTextToken;
                $tokenParts = explode('|', $plainToken);
                $token = isset($tokenParts[1]) ? $tokenParts[1] : $plainToken;
                return response()->json([
                    'message' => 'Login su  ccessful',
                    'token' => $token,
                    'client' => $client
                ], 200);
            } else if ($clientNew) {
                return response()->json(['message' => 'Client exists in clientnew table'], 401);
            }
        }
    }

    public function me(Request $request)
    {
        return response()->json($request->user());
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();
        return response()->json(['message' => 'تم تسجيل الخروج']);
    }
}
